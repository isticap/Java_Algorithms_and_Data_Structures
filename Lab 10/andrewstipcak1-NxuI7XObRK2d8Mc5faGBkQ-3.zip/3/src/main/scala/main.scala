def fac(n: BigInt): BigInt = {
  if (n <= 1)
    1
  else
    n * fac(n-1)
}

//lets rewrite the above so that it is tail recursive.

def facTailRecursive(n: BigInt): BigInt = {
  def fac_(n: BigInt, r: BigInt): BigInt = {
    if(n <= 1)
      r
    else
      fac_(n-1, n * r)
  }
  fac_(n, 1)
}

facTailRecursive(1000)