object Example {
  def main(args: Array[String]): Unit = {
    //println(s"2 ^ 5 = ${powNonTailRecursive(2,5)}")
    println(s"2 ^ 3 = ${powTailRecursive(2,3)}")
    
  }
  
  
  
  def powNonTailRecursive(b: BigInt, e: Int):BigInt = {
    if (e == 0)
      1
    else
      b * powNonTailRecursive(b, e-1)
  }
  
  def powTailRecursive(b: BigInt, e: Int):BigInt = {
    def pow_(b: BigInt, e: Int, r: BigInt):BigInt = {
      if (b < 1)
        r
      else
        pow_(b, e-1, b * r)
    }
    pow_(b, e, 1)
  }
}