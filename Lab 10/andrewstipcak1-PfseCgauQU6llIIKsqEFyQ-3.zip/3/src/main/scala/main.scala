//the below is the scala equivalent to public static void main...

object Main {
  def main(args: Array[String]): Unit = {
    val p1 = new Point
    val p2 = new Point(3,5)
    print(s"The distance b/t the two points ${p1} and ${p2} is ")
    println(p1 distance p2)
  }
  
  class Point(var x: Int = 0, var y: Int = 0){
    def move(dx: Int, dy: Int): Unit = {
      x += dx
      y += dy
    }
    
    def distance(p: Point): Double = {
      val xdiff = x - p.x
      val ydiff = y - p.y
      Math.sqrt(xdiff * xdiff + ydiff * ydiff)
    }
    
    override def toString: String = 
      s"($x, $y)"
  }
}